import { AppServer } from "./app"

export const appServer: AppServer = new AppServer()
appServer.start()
// appServer.crons()
