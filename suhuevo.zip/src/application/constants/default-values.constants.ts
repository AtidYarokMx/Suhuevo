export const defaultCountry = 'MX'
export const defaultEmail = 'jair.marquez.rubio@gmail.com'
