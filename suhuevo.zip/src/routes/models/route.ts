import { Router } from 'express'

export class ServerRouter {
  public router: Router = Router()
}
