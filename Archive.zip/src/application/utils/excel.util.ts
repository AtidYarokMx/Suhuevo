export function generateHeaders() {
  // pendiente de hacer
}