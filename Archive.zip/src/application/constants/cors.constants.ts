export const cors = {
  credentials: true,
  origin: '*'
  // [
  //   'http://localhost:5173',
  //   'http://localhost:5174',
  //   'http://localhost:5175',
  //   'http://localhost:5176',
  //   'http://localhost:8100',
  //   'https://localhost:8100',
  //   'https://192.168.100.145:8100'
  // ]
}
